package com.example.piano

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults.buttonColors
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.piano.ui.theme.PianoTheme
import android.content.Context
import android.media.AudioTrack
import android.net.Uri
import android.net.Uri.Builder
import androidx.compose.foundation.border
import androidx.compose.runtime.currentCompositionLocalContext
import androidx.compose.ui.platform.LocalContext
import java.net.URL
import kotlin.coroutines.coroutineContext
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            PianoTheme () {
                Surface() {
                    Teclas()
                }
            }
        }
    }
}

@Composable
fun Teclas(){
    val context = LocalContext.current
    val notas = remember {
        mapOf(
            "1" to MediaPlayer.create(context, R.raw.a3),
            "2" to MediaPlayer.create(context, R.raw.b),
            "3" to MediaPlayer.create(context, R.raw.c),
            "4" to MediaPlayer.create(context, R.raw.d),
            "5" to MediaPlayer.create(context, R.raw.e),
            "6" to MediaPlayer.create(context, R.raw.f),
            "7" to MediaPlayer.create(context, R.raw.g)
        )
    }

    Column (modifier = Modifier.fillMaxHeight().background(Color.Black).padding(vertical = 50.dp), verticalArrangement = Arrangement.SpaceAround) {
        notas.forEach { (name, mediaPlayer) ->
            Tecla(name =name, mediaPlayer = mediaPlayer)

        }
    }
}

@Composable
fun Tecla(name: String,mediaPlayer: MediaPlayer,
          modifier: Modifier = Modifier
              .background(Color.Black)
){
    val notas = remember { mediaPlayer }
        Button (onClick = { notas.start() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                border = BorderStroke(1.dp, Color.Black),
                shape = RoundedCornerShape(0),
                colors = buttonColors(containerColor = Color.White),
        ) {}
}